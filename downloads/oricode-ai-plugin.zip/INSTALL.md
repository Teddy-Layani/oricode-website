# Oricode AI Installation Guide

## Requirements

- Eclipse IDE with ADT (ABAP Development Tools)
- SAP system access (user/password)
- Oricode AI account → [app.oricode.ai](https://app.oricode.ai)

---

## Quick Install (5 minutes)

### Step 1: Install Eclipse Plugin

1. Copy `plugin/com.oricode.ai.jar` to your Eclipse dropins folder:
   - **Windows:** `C:\Users\YOUR_USER\eclipse\dropins\`
   - **Mac:** `~/eclipse/dropins/`
   - **Linux:** `~/eclipse/dropins/`

2. Restart Eclipse

---

### Step 2: Configure MCP Server

1. Navigate to `mcp-server/` folder
2. Copy `config.example.properties` → `config.properties`
3. Edit `config.properties` with your SAP details:

```properties
SAP_URL=https://your-sap-server.com:44300
SAP_CLIENT=100
SAP_USER=your_sap_user
SAP_PASSWORD=your_sap_password
```

---

### Step 3: Start MCP Server

**Windows:**
```
Double-click start-mcp.bat
```

**Mac/Linux:**
```bash
chmod +x start-mcp.sh
./start-mcp.sh
```

You should see:
```
========================================
 Oricode MCP Server for SAP ABAP
========================================

SAP Server: https://your-sap-server.com:44300
Starting MCP Server...
```

**Keep this terminal open!**

---

### Step 4: Configure Eclipse Plugin

1. In Eclipse: **Window → Preferences → Oricode AI**
2. Enter your **API Key** from [app.oricode.ai/dashboard](https://app.oricode.ai/dashboard)
3. Click **Apply and Close**

---

### Step 5: Start Using!

1. Open View: **Window → Show View → Other → Oricode AI**
2. Select your ABAP project
3. Start chatting!

---

## Features

| Feature | Description |
|---------|-------------|
| 💬 Chat | Ask questions about ABAP code |
| 🔍 Search | Find classes, programs, tables |
| 📖 Read | View source code and definitions |
| ✏️ Create | Generate new ABAP objects |
| 📝 Modify | Edit existing code |
| ✅ Activate | Activate objects |
| 📦 Transport | Manage transport requests |

---

## Troubleshooting

### SSL Certificate Errors

If you see SSL errors:
1. Use `http://` instead of `https://` in SAP_URL
2. Or add `SAP_SKIP_SSL=true` to config.properties

### MCP Server Won't Start

1. Check `config.properties` exists
2. Verify SAP credentials are correct
3. Test SAP connection in browser first

### Plugin Not Loading

1. Verify JAR is in correct dropins folder
2. Restart Eclipse completely
3. Check: **Window → Show View → Error Log**

### Connection Refused

1. Make sure MCP server is running
2. Check firewall settings
3. Verify SAP server is accessible

---

## Support

- 📧 Email: support@oricode.ai
- 🎯 Dashboard: [app.oricode.ai](https://app.oricode.ai)
