# Oricode AI Installation Guide

## Requirements

- Eclipse IDE with ADT (ABAP Development Tools)
- SAP system access
- Oricode AI account → [app.oricode.ai](https://app.oricode.ai)

---

## Quick Install

### Step 1: Install Eclipse Plugin

1. Copy `plugin/com.oricode.eclipse.ai_1.0.6.jar` to your Eclipse dropins folder:
   - **Windows:** `C:\Users\YOUR_USER\eclipse\dropins\`
   - **Mac:** `~/eclipse/dropins/`
   - **Linux:** `~/eclipse/dropins/`

2. Restart Eclipse

---

### Step 2: Configure SAP Connection

Oricode supports two types of SAP systems with different authentication methods:

#### Option A: SAP On-Premise (Basic Auth)

For traditional SAP systems (ECC, S/4HANA on-premise):

1. Navigate to `mcp-server/` folder
2. Copy `config.example.properties` → `config.properties`
3. Edit `config.properties`:

```properties
SAP_URL=https://your-sap-server.com:44300
SAP_CLIENT=100
SAP_USER=your_sap_user
SAP_PASSWORD=your_sap_password
SAP_AUTH_TYPE=basic
```

| Property | Description | Example |
|----------|-------------|---------|
| SAP_URL | SAP server URL with port | `https://sap-dev.company.com:44300` |
| SAP_CLIENT | SAP client number | `100`, `200`, `800` |
| SAP_USER | SAP username | `DEVELOPER` |
| SAP_PASSWORD | SAP password | `yourpassword` |
| SAP_AUTH_TYPE | Authentication type | `basic` |

---

#### Option B: SAP BTP / ABAP Cloud (Browser Auth)

For SAP Business Technology Platform and ABAP Cloud systems (including those with 2FA):

1. Navigate to `mcp-server/` folder
2. Copy `config.example.properties` → `config.properties`
3. Edit `config.properties`:

```properties
SAP_URL=https://xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.abap.us10.hana.ondemand.com
SAP_AUTH_TYPE=browser
```

| Property | Description | Example |
|----------|-------------|---------|
| SAP_URL | ABAP Cloud API URL (`.abap.` domain) | `https://abc123.abap.us10.hana.ondemand.com` |
| SAP_AUTH_TYPE | Authentication type | `browser` |

**Important notes for ABAP Cloud:**
- Use the `.abap.` URL (API domain), NOT the `.abap-web.` URL (browser domain)
- No username/password needed - authentication happens in your browser
- Client is always `100` for ABAP Cloud (automatic)
- Supports 2FA / Multi-Factor Authentication

**How browser auth works:**
1. When you connect, your default browser opens to SAP's login page
2. Authenticate with your Identity Provider (Azure AD, SAP IAS, etc.)
3. Complete 2FA if required
4. Browser redirects back and the plugin captures the session automatically

**Finding your ABAP Cloud URL:**
1. In BTP Cockpit → Your Subaccount → Instances and Subscriptions
2. Find your ABAP environment instance
3. Look for the service key or binding - the URL format is:
   `https://<guid>.abap.<region>.hana.ondemand.com`

---

### Step 3: Start MCP Server

**Windows:**
```
Double-click start-mcp.bat
```

**Mac/Linux:**
```bash
chmod +x start-mcp.sh
./start-mcp.sh
```

You should see:
```
========================================
 Oricode MCP Server for SAP ABAP
========================================

SAP Server: https://your-sap-server.com
Starting MCP Server...
```

**Keep this terminal open!**

---

### Step 4: Configure Eclipse Plugin

1. In Eclipse: **Window → Preferences → Oricode AI**
2. Enter your **API Key** from [app.oricode.ai/dashboard](https://app.oricode.ai/dashboard)
3. Click **Apply and Close**

---

### Step 5: Start Using!

1. Open View: **Window → Show View → Other → Oricode AI**
2. Select your ABAP project
3. Start chatting!

**Chat shortcuts:**
- **Enter** → Send message
- **Shift+Enter** → New line

---

## Features

| Feature | Description |
|---------|-------------|
| 💬 Chat | Ask questions about ABAP code |
| 🔍 Search | Find classes, programs, tables |
| 📖 Read | View source code and definitions |
| ✏️ Create | Generate new ABAP objects |
| 📝 Modify | Edit existing code |
| ✅ Activate | Activate objects |
| 📦 Transport | Manage transport requests |

---

## Troubleshooting

### SSL Certificate Errors

If you see SSL errors:
1. Use `http://` instead of `https://` in SAP_URL
2. Or add `SAP_SKIP_SSL=true` to config.properties

### MCP Server Won't Start

1. Check `config.properties` exists
2. Verify SAP credentials are correct
3. Test SAP connection in browser first

### Plugin Not Loading

1. Verify JAR is in correct dropins folder
2. Restart Eclipse completely
3. Check: **Window → Show View → Error Log**

### Connection Refused

1. Make sure MCP server is running
2. Check firewall settings
3. Verify SAP server is accessible

---

## Support

- 📧 Email: support@oricode.ai
- 🎯 Dashboard: [app.oricode.ai](https://app.oricode.ai)
