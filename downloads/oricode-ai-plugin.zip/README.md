# Oricode AI Bundle

🤖 AI-powered ABAP development assistant for Eclipse ADT.

---

## What's Included

```
oricode-ai-bundle/
├── plugin/
│   └── com.oricode.ai.jar    # Eclipse plugin
│
├── mcp-server/
│   ├── oricode-mcp-server.exe      # Windows
│   ├── oricode-mcp-server-macos    # Mac
│   ├── oricode-mcp-server-linux    # Linux
│   ├── config.example.properties   # SAP config template
│   ├── start-mcp.bat               # Windows launcher
│   └── start-mcp.sh                # Mac/Linux launcher
│
├── INSTALL.md                       # Installation guide
└── README.md                        # This file
```

---

## Quick Start

1. **Install plugin** → Copy JAR to Eclipse dropins → Restart
2. **Configure MCP** → Edit `config.properties` with SAP credentials
3. **Start MCP server** → Run `start-mcp.bat` (Windows) or `start-mcp.sh`
4. **Add API key** → Eclipse Preferences → Oricode AI
5. **Start chatting!** → Window → Show View → Oricode AI

📖 See `INSTALL.md` for detailed instructions.

---

## Get Your API Key

Sign up free at **[app.oricode.ai](https://app.oricode.ai)**

---

## Features

- 💬 **Chat** - Ask Claude AI about ABAP code
- 🔍 **Search** - Find objects across SAP system  
- 📖 **Read** - View source code, tables, definitions
- ✏️ **Create** - Generate classes, programs, includes
- 📝 **Modify** - Edit and update existing code
- ✅ **Activate** - Activate objects in SAP
- 📦 **Transport** - Create and manage transports

---

## Links

| | |
|---|---|
| 🌐 Website | [oricode.ai](https://oricode.ai) |
| 🎯 Dashboard | [app.oricode.ai](https://app.oricode.ai) |
| 📧 Support | support@oricode.ai |

---

© 2026 Oricode AI • Built for SAP developers
